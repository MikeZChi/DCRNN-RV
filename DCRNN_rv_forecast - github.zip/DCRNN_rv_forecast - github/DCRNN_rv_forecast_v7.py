# -*- coding: utf-8 -*-
"""
Created on Fri May 10 16:38:10 2024

@author: MC
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import argparse
import numpy as np
import pandas as pd
import torch
import utils_v7 as utils
import torch.nn as nn
import time
import yaml
import sys
#from utils import load_graph_data
import warnings
warnings.filterwarnings('ignore')


os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
### Set device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


### Define Loss Function
def mae_loss(y_pred, y_true, Ey):
    y_true_reshaped = y_true.transpose(0, 1)
    y_pred_reshaped = y_pred.transpose(0, 1)
    # dim(y_true_reshaped) = [batch_size, horizon, input_dim]
    # dim(y_pred_reshaped) = [batch_size, horizon, input_dim]
    # dim(Ey) = [batch_size, horizon, num_node]
    loss = torch.abs(y_pred_reshaped - y_true_reshaped)
    loss_filter_matrix = Ey.to(loss.device)
    loss = loss_filter_matrix * loss
    sum_loss = torch.sum(loss)
    trading_days = torch.count_nonzero(loss_filter_matrix)
    result = sum_loss / trading_days
    return result



### DCRNNCell Definition
class LayerParams:
    def __init__(self, rnn_network: torch.nn.Module, layer_type: str):
        self._rnn_network = rnn_network # An instance of a neural network layer from torch.nn.Module
        self._params_dict = {}
        self._biases_dict = {}
        self._type = layer_type # str: A string specifying the type of the layer (like "LSTM", "GRU", etc.)

    def get_weights(self, shape): # input is the desired shape of the parameter tensor
        if shape not in self._params_dict:
            # initializes a new torch.nn.Parameter with empty values
            nn_param = torch.nn.Parameter(torch.empty(*shape, device=device))
            # applies Xavier Normal initialization (torch.nn.init.xavier_normal_) to nn_param
            torch.nn.init.xavier_normal_(nn_param)
            # The keys of self._params_dict are shape tuples
            self._params_dict[shape] = nn_param
            # Create a unique for parameters. format: self._type + '_weight_' + str(shape) e.g., LSTM_weight_(3, 5) and assign nn_param
            self._rnn_network.register_parameter('{}_weight_{}'.format(self._type, str(shape)), nn_param)
        return self._params_dict[shape]

    def get_biases(self, length, bias_start=0.0): # bias_start: The initial value for all elements of the bias parameter
        if length not in self._biases_dict:
            biases = torch.nn.Parameter(torch.empty(length, device=device))
            torch.nn.init.constant_(biases, bias_start) # arg 1: the tensor to initialize, arg 2: the constant value to initialize with
            self._biases_dict[length] = biases
            self._rnn_network.register_parameter('{}_biases_{}'.format(self._type, str(length)), biases)

        return self._biases_dict[length]


class DCGRUCell(torch.nn.Module):
    def __init__(self, num_units, adjacency_list, filter_matrix, adj_mx, rolling_window, max_diffusion_step, num_nodes, nonlinearity='tanh',
                 filter_type="laplacian", use_gc_for_ru=True):
        """
        :param num_units:
        :param adjacency_list:
        :param adj_mx:
        :param rolling_window: bool
        :param max_diffusion_step: k
        :param num_nodes:
        :param nonlinearity:
        :param filter_type: "laplacian", "random_walk", "dual_random_walk".
        :param use_gc_for_ru: whether to use Graph convolution to calculate the reset and update gates.
        """

        super().__init__() 
        self._activation = torch.tanh if nonlinearity == 'tanh' else torch.relu
        self._num_nodes = num_nodes # the number of nodes in the graph
        self._num_units = num_units # the number of neurons in a layer, which is the dimension of hidden state
        self._max_diffusion_step = max_diffusion_step
        self.rolling_window = rolling_window
        self._supports = [] # initialize self._supports as []
        self._use_gc_for_ru = use_gc_for_ru
        if self.rolling_window == False:
            supports = []
            adj_mx_expanded = torch.tensor(adj_mx, dtype=torch.float32).unsqueeze(0)
            adj_mx_expanded = adj_mx_expanded.to(filter_matrix.device)
                # dim(adj_mx_expanded) = [1, num_nodes, num_nodes]
            filtered_adj_mx = filter_matrix * adj_mx_expanded 
                # dim(filtered_adj_mx) = [batch_size, num_nodes, num_nodes]
            filtered_adj_mx_list = [filtered_adj_mx[i] for i in range(filtered_adj_mx.size(0))]
            # print(filtered_adj_mx_list[0].size()) = [num_nodes, num_nodes]
            
            # Construct graph convolutions
            if filter_type == "laplacian":
                supports = [utils.calculate_scaled_laplacian(mx.cpu().numpy().astype('float32'), lambda_max=None) for mx in filtered_adj_mx_list]
                    # dim(mx) = [num_nodes, num_nodes], len(supports) = batch_size, lambda_max has to be set manually
            elif filter_type == "random_walk":
                supports = [utils.calculate_random_walk_matrix(mx.cpu().numpy().astype('float32')) for mx in filtered_adj_mx_list]
                    # dim(mx) = [num_nodes, num_nodes], len(supports) = batch_size
                # utils.calculate_random_walk_matrix(adj_mx)
                    # The random walk matrix is the transition prob matrix: D^(-1)W
                    # Take the transpose: the transition prob matrix from downstream to upstream (traffic flow prediction)
            # elif filter_type == "dual_random_walk":
                # supports.append(utils.calculate_random_walk_matrix(adj_mx))
                # supports.append(utils.calculate_random_walk_matrix(adj_mx.T))
            else:
                supports = [utils.calculate_scaled_laplacian(mx.cpu().numpy().astype('float32'), lambda_max=None) for mx in filtered_adj_mx_list]
            
            
            self._supports = supports
                # dim(support) = (num_node, num_node)
                
            self._fc_params = LayerParams(self, 'fc')

            self._gconv_params = LayerParams(self, 'gconv')
        
        elif self.rolling_window == True:
            supports = []
            adj_mx_expanded = adjacency_list
                # dim(adj_mx_expanded) = [batch_size, num_nodes, num_nodes]
            adj_mx_expanded = adj_mx_expanded.to(device)
            filter_matrix = filter_matrix.to(device)
            filtered_adj_mx = filter_matrix * adj_mx_expanded 
                # dim(filtered_adj_mx) = [batch_size, num_nodes, num_nodes]
            filtered_adj_mx_list = [filtered_adj_mx[i] for i in range(filtered_adj_mx.size(0))]
                # dim(filtered_adj_mx_list[i]) = [num_nodes, num_nodes]
            # Construct graph convolutions
            if filter_type == "laplacian":
                supports = [utils.calculate_scaled_laplacian(mx.cpu().numpy().astype('float32'), lambda_max=None) for mx in filtered_adj_mx_list]
                    # dim(mx) = [num_nodes, num_nodes], len(supports) = batch_size, lambda_max has to be set manually
            elif filter_type == "random_walk":
                supports = [utils.calculate_random_walk_matrix(mx.cpu().numpy().astype('float32')) for mx in filtered_adj_mx_list]
                    # dim(mx) = [num_nodes, num_nodes], len(supports) = batch_size
                # utils.calculate_random_walk_matrix(adj_mx)
                    # The random walk matrix is the transition prob matrix: D^(-1)W
                    # Take the transpose: the transition prob matrix from downstream to upstream (traffic flow prediction)
            # elif filter_type == "dual_random_walk":
                # supports.append(utils.calculate_random_walk_matrix(adj_mx))
                # supports.append(utils.calculate_random_walk_matrix(adj_mx.T))
            else:
                supports = [utils.calculate_scaled_laplacian(mx.cpu().numpy().astype('float32'), lambda_max=None) for mx in filtered_adj_mx_list]
                 
            self._supports = supports
                # dim(support) = (num_node, num_node)
            
                
            self._fc_params = LayerParams(self, 'fc')

            self._gconv_params = LayerParams(self, 'gconv')
        
        else:
            raise ValueError("Wrong argument for rolling_window")
            sys.exit(1)

    @staticmethod
    def _build_sparse_matrix(L): # see trial.ipynb on Jupyter
        L = L.tocoo()
        indices = np.column_stack((L.row, L.col))
        indices = indices[np.lexsort((indices[:, 0], indices[:, 1]))]
        L = torch.sparse_coo_tensor(indices.T, L.data, L.shape, device=device)
        return L
    
    def _fc(self, inputs, state, output_size, bias_start=0.0): # error free
        batch_size = inputs.shape[0]
        inputs = torch.reshape(inputs, (batch_size * self._num_nodes, -1))
            # (batch size, num_nodes * input_dim) --> (batch size * num_nodes, input_dim)
            
        state = torch.reshape(state, (batch_size * self._num_nodes, -1))
            # (batch size, num_nodes * rnn_units) --> (batch size * num_nodes, rnn_units)
            
        inputs_and_state = torch.cat([inputs, state], dim=-1)
            # dim(inputs_and_state) = (batch_size * num_nodes, input_dim + rnn_units)
        input_size = inputs_and_state.shape[-1] # new feature dimension
        weights = self._fc_params.get_weights((input_size, output_size))
        value = torch.matmul(inputs_and_state, weights)
        biases = self._fc_params.get_biases(output_size, bias_start)
        value += biases
        bn = nn.BatchNorm1d(value.shape[-1]).to(value.device)
        value = bn(value)
        return value # dim(value) = (batch_size * num_nodes, output_size)
    
    @staticmethod
    def _concat(x, x_):
        x_ = x_.unsqueeze(0) # dim(x_) = [m,n] --> [1, m, n]
        return torch.cat([x, x_], dim=0) # dim(x) should be [?, m, n]
            # dim(output) = [?+1, m, n]
    
    def _gconv(self, inputs, state, output_size, bias_start=0.0):
        # dim(inputs) = (batch size, num_nodes * input_dim), input_dim is node feature size
        # dim(inputs) = (batch size, num_nodes * rnn_units), input_dim is hidden state size
        # The above difference is caused by the mechanism of RNN
        # dim(state) = (batch size, num_nodes * num_units), num_units is state feature size = rnn_units in config
        batch_size = inputs.shape[0]
        inputs = torch.reshape(inputs, (batch_size, self._num_nodes, -1))
            # (batch size, num_nodes * input_dim) --> (batch size, num_nodes, input_dim)
        state = torch.reshape(state, (batch_size, self._num_nodes, -1))
            # (batch size, num_nodes * num_units) --> (batch size, num_nodes, num_units)
        inputs_and_state = torch.cat([inputs, state], dim=2)
            # input is hidden input: dim(inputs_and_state) = (batch size, num_nodes, num_units + input_dim)
            # input is hidden state: dim(inputs_and_state) = (batch size, num_nodes, num_units + num_units)
        input_size = inputs_and_state.size(2)
            # input_size = input_dim + num_units. input feature size
        x = inputs_and_state
            # dim(x) = (batch size, num_nodes, input_dim + num_units)
        # Reshape x0 to separate the batch dimension @ mc
        x0_reshape = x
            # dim(x0_reshape) = [batch_size, num_nodes, input_dim + num_units or num_units + num_units]
        if self._max_diffusion_step == 0:
            pass
        else:
            x_list = []
            if self.rolling_window == True:
                supports = torch.stack([torch.tensor(s, dtype=torch.float32) for s in self._supports]).to(x.device)
                    # dim(supports) = [batch_size, num_nodes, num_nodes]
                x1_reshape = torch.bmm(supports, x0_reshape)  # Batch matrix multiplication
                    # dim(x1_reshape) = [batch_size, num_nodes, input_size]
                # Reshape
                x0_reshape_copy = x0_reshape.permute(1, 2, 0)
                x0_reshape_copy = x0_reshape_copy.reshape(x0_reshape_copy.shape[0], -1)
                    # dim(x0_reshape) = [num_nodes, input_size * batch_size]
                x1_reshape_copy = x1_reshape.permute(1, 2, 0)
                x1_reshape_copy = x1_reshape_copy.reshape(x1_reshape_copy.shape[0], -1)
                    # dim(x1_reshape) = [num_nodes, input_size * batch_size]
                    
                x_list = [x0_reshape_copy.unsqueeze(0), x1_reshape_copy.unsqueeze(0)]
    
                for k in range(2, self._max_diffusion_step + 1):
                    x2_reshape = 2 * torch.bmm(supports, x1_reshape) - x0_reshape
                        # dim(x2_reshape) = [batch_size, num_nodes, input_size]
                    # Reshape
                    x2_reshape_copy = x2_reshape.permute(1, 2, 0)
                    x2_reshape_copy = x2_reshape_copy.reshape(x2_reshape_copy.shape[0], -1)
                        # dim(x2_reshape_copy) = [num_nodes, input_size * batch_size]
                    x_list.append(x2_reshape_copy.unsqueeze(0))
                        # dim(x_list[i]) = [1, batch_size, num_nodes, input_size]
                    x1_reshape, x0_reshape = x2_reshape, x1_reshape
                # Stack the tensors along the first dimension
                x = torch.cat(x_list, dim=0)
                # dim(x) = (k+1, num_nodes, batch_size * input_size)
                
            else: # self.rolling_window == False:
                supports = torch.stack([torch.tensor(s, dtype=torch.float32) for s in self._supports]).to(x.device)
                    # dim(supports) = [batch_size, num_nodes, num_nodes]
                x1_reshape = torch.bmm(supports, x0_reshape)  # Batch matrix multiplication
                    # dim(x1_reshape) = [batch_size, num_nodes, input_size]
                # Reshape
                x0_reshape_copy = x0_reshape.permute(1, 2, 0)
                x0_reshape_copy = x0_reshape_copy.reshape(x0_reshape_copy.shape[0], -1)
                    # dim(x0_reshape) = [num_nodes, input_size * batch_size]
                x1_reshape_copy = x1_reshape.permute(1, 2, 0)
                x1_reshape_copy = x1_reshape_copy.reshape(x1_reshape_copy.shape[0], -1)
                    # dim(x1_reshape) = [num_nodes, input_size * batch_size]
                    
                x_list = [x0_reshape_copy.unsqueeze(0), x1_reshape_copy.unsqueeze(0)]
    
                for k in range(2, self._max_diffusion_step + 1):
                    x2_reshape = 2 * torch.bmm(supports, x1_reshape) - x0_reshape
                        # dim(x2_reshape) = [batch_size, num_nodes, input_size]
                    # Reshape
                    x2_reshape_copy = x2_reshape.permute(1, 2, 0)
                    x2_reshape_copy = x2_reshape_copy.reshape(x2_reshape_copy.shape[0], -1)
                        # dim(x2_reshape_copy) = [num_nodes, input_size * batch_size]
                    x_list.append(x2_reshape_copy.unsqueeze(0))
                        # dim(x_list[i]) = [1, batch_size, num_nodes, input_size]
                    x1_reshape, x0_reshape = x2_reshape, x1_reshape
                # Stack the tensors along the first dimension
                x = torch.cat(x_list, dim=0)
                # dim(x) = (k+1, num_nodes, batch_size * input_size)
        
        ### AXW + B
        # calculate the number of matrices needed = k * number of graph convolution matrix + 1
        num_matrices = self._max_diffusion_step + 1 # dual random walk is not allowed  
        x = torch.reshape(x, shape=[num_matrices, self._num_nodes, input_size, batch_size])
        x = x.permute(3, 1, 2, 0)
            # dim(x) = (batch_size, num_nodes, (input_dim + num_units), num_matrices)
        x = torch.reshape(x, shape=[batch_size * self._num_nodes, input_size * num_matrices])
            # dim(x) = (batch_size * num_nodes, (input_dim + num_units) * num_matrices)
            # num of obs = batch_size * num_nodes, num of features (input_size) = (input_dim + num_units) * num_matrices
        weights = self._gconv_params.get_weights((input_size * num_matrices, output_size))
            # dim(weights) = ((input_dim + num_units) * num_matrices, output_size)
            # output_size = 2 * num_units

        x = torch.matmul(x, weights)  # (batch_size * num_nodes, output_size)
        biases = self._gconv_params.get_biases(output_size, bias_start)

        x += biases
        bn = nn.BatchNorm1d(x.shape[-1]).to(x.device)
        x = bn(x)
        # Reshape res back to 2D: (batch_size, num_node, state_dim) -> (batch_size, num_node * state_dim)
        return torch.reshape(x, [batch_size, self._num_nodes * output_size])
        # the number of parameters has nothing to do with seq_len.

    def forward(self, inputs, hx):
        """Gated recurrent unit (GRU) with Graph Convolution.
        :param inputs (x): (batch size, num_nodes * input_dim)
        :param hx (hidden states): (batch size, num_nodes * num_units) (num_units = rnn_units)

        :return
        - Output: A `2-D` tensor with shape `(batch size, num_nodes * 2 * num_units)`.
        """
        output_size = 2 * self._num_units
        if self._use_gc_for_ru:
            fn = self._gconv
        else:
            fn = self._fc
        value = fn(inputs, hx, output_size, bias_start=0.0001) # SLP
        value = torch.reshape(value, (-1, self._num_nodes, output_size))
            # (batch_size * num_nodes, output_size) --> (batch_size, num_nodes, output_size)


        # split the tensor value into two parts along the last dimension (indicated by dim=-1)
        r, u = torch.split(tensor=value, split_size_or_sections=self._num_units, dim=-1)
            # dim(r), dim(u) = (batch_size, num_nodes, output_size/2) = (batch_size, num_nodes, self._num_units)

        r = torch.sigmoid(r)
        u = torch.sigmoid(u)
        
        r = torch.reshape(r, (-1, self._num_nodes * self._num_units))
            # (batch_size, num_nodes, self._num_units) --> (batch_size, num_nodes * self._num_units)
        u = torch.reshape(u, (-1, self._num_nodes * self._num_units))
            # (batch_size, num_nodes, self._num_units) --> (batch_size, num_nodes * self._num_units)
        c = self._gconv(inputs, r * hx, self._num_units) # self._gconv only output linear transformed results
        if self._activation is not None:
            c = self._activation(c)
        
        # r & u are transformed through sigmoid activagtion funciton
        new_state = u * hx + (1.0 - u) * c  # there is no nan values in the new_state at the first few batches
            # dim(new_state) = (batch_size, num_nodes * self._num_units)
        return new_state

class Seq2SeqAttrs: # For RNN, the number of parameters has nothing to do with seq_len.
    def __init__(self, adj_mx, **model_kwargs):
        # model_kwargs.get(var_name. default_value)
        self.adj_mx = adj_mx
        self.max_diffusion_step = int(model_kwargs.get('max_diffusion_step', 2))
        self.rolling_window = bool(model_kwargs.get('rolling_window', False))
        # self.cl_decay_steps = int(model_kwargs.get('cl_decay_steps', 1000))
        self.filter_type = model_kwargs.get('filter_type', 'laplacian')
        self.num_nodes = int(model_kwargs.get('num_nodes', 1))
        self.num_rnn_layers = int(model_kwargs.get('num_rnn_layers', 1))
        self.rnn_units = int(model_kwargs.get('rnn_units'))
        self.hidden_state_size = self.num_nodes * self.rnn_units


class EncoderModel(nn.Module, Seq2SeqAttrs): # The EncoderModel inherits from the two classes nn.Module and Seq2SeqAttrs
    def __init__(self, adj_mx, **model_kwargs):
        # need to initialize both parent classes
        nn.Module.__init__(self) # initializes the nn.Module part of EncoderModel
        Seq2SeqAttrs.__init__(self, adj_mx, **model_kwargs) # initialize Seq2SeqAttrs
        self.input_dim = int(model_kwargs.get('input_dim', 1))
        self.seq_len = int(model_kwargs.get('seq_len'))  # for the encoder
        self.adj_mx = adj_mx
        self.dcgru_layers = None

    def forward(self, inputs, adjacency_list, filter_matrix, hidden_state=None):
        """
        Encoder forward pass.

        :param inputs: shape (batch_size, self.num_nodes * self.input_dim)
        :param hidden_state: (num_layers, batch_size, self.hidden_state_size)
               optional, zeros if not provided
        :return: output: # shape (batch_size, self.hidden_state_size)
                 hidden_state # shape (num_layers, batch_size, self.hidden_state_size)
                 (lower indices mean lower layers)
        """
        # Initialize dcgru_layers if not already initialized
        if self.dcgru_layers is None:
            self.dcgru_layers = nn.ModuleList(
                [DCGRUCell(self.rnn_units, adjacency_list, filter_matrix, self.adj_mx, self.rolling_window, self.max_diffusion_step, self.num_nodes,
                           filter_type=self.filter_type) for _ in range(self.num_rnn_layers)])
        
        batch_size, _ = inputs.size() # inputs work well here 
        if hidden_state is None: # hidden state initialization
            hidden_state = torch.zeros((self.num_rnn_layers, batch_size, self.hidden_state_size), device=device) # do initialize
        hidden_states = []
        output = inputs
        for layer_num, dcgru_layer in enumerate(self.dcgru_layers):
            next_hidden_state = dcgru_layer(output, hidden_state[layer_num])
            hidden_states.append(next_hidden_state)
            output = next_hidden_state
            # dim(output) = (batch_size, num_nodes * self._num_units)
        return output, torch.stack(hidden_states)  # runs in O(num_layers) so not too slow
        # dim(torch.stack(hidden_states)) = (2, batch_size, num_nodes * self._num_units)
        
class DecoderModel(nn.Module, Seq2SeqAttrs):
    def __init__(self, adj_mx, **model_kwargs):
        nn.Module.__init__(self)
        Seq2SeqAttrs.__init__(self, adj_mx, **model_kwargs)
        self.output_dim = int(model_kwargs.get('output_dim', 1))
        self.horizon = int(model_kwargs.get('horizon', 1))  # define forecast horizon for the decoder
        self.projection_layer = nn.Linear(self.rnn_units, self.output_dim)
        self.adj_mx = adj_mx
        self.dcgru_layers = None

    def forward(self, inputs, adjacency_list, hidden_state=None):
        """
        Decoder forward pass.

        :param inputs: shape (batch_size, self.num_nodes * self.output_dim)
        :param hidden_state: (num_layers, batch_size, self.hidden_state_size)
               optional, zeros if not provided
        :return: output: # shape (batch_size, self.num_nodes * self.output_dim)
                 hidden_state # shape (num_layers, batch_size, self.hidden_state_size)
                 (lower indices mean lower layers)
        """
        filter_matrix = torch.ones((inputs.size()[0], inputs.size()[1], inputs.size()[1]), dtype=torch.float32)
        # Initialize dcgru_layers if not already initialized
        if self.dcgru_layers is None:
            self.dcgru_layers = nn.ModuleList(
               [DCGRUCell(self.rnn_units, adjacency_list, filter_matrix, self.adj_mx, self.rolling_window, self.max_diffusion_step,
                          self.num_nodes, filter_type=self.filter_type) for _ in range(self.num_rnn_layers)])
        inputs = inputs.to(dtype=torch.float32)
        if hidden_state is not None:
            hidden_state = [hs.to(dtype=torch.float32) for hs in hidden_state]  # Convert hidden state to float32 if provided
        hidden_states = []
        output = inputs
        for layer_num, dcgru_layer in enumerate(self.dcgru_layers):
            next_hidden_state = dcgru_layer(output, hidden_state[layer_num])
            hidden_states.append(next_hidden_state)
            output = next_hidden_state
        
        output = output.to(dtype=torch.float32)  # Ensure output is float32 before projection
        projected = self.projection_layer(output.view(-1, self.rnn_units))
        output = projected.view(-1, self.num_nodes * self.output_dim) # get final output

        return output, torch.stack(hidden_states)

########## Seq2Seq archetecture, Encoder, Decoder, basic DCRNNCell and other modules are formulated above

### DCRNNModel Definition
class DCRNNModel(nn.Module, Seq2SeqAttrs): # archetecture: encoder + decoder
    def __init__(self, adj_mx, **model_kwargs):
        super().__init__()
        Seq2SeqAttrs.__init__(self, adj_mx, **model_kwargs)
        self.encoder_model = EncoderModel(adj_mx, **model_kwargs)
        self.decoder_model = DecoderModel(adj_mx, **model_kwargs)
        #self.cl_decay_steps = int(model_kwargs.get('cl_decay_steps', 1000))
        self.use_curriculum_learning = bool(model_kwargs.get('use_curriculum_learning', False)) # disable curriculum learning

    #def _compute_sampling_threshold(self, batches_seen):
        # batches_seen: This parameter is an integer that tracks the number of batches that have been processed so far during training.
        #return self.cl_decay_steps / (
        #        self.cl_decay_steps + np.exp(batches_seen / self.cl_decay_steps))

    def encoder(self, inputs, adjacency_list, filter_matrix):
        """
        encoder forward pass on t time steps
        :param inputs: shape (seq_len, batch_size, num_sensor * input_dim)
        :return: encoder_hidden_state: (num_layers, batch_size, self.hidden_state_size)
        """
       
        encoder_hidden_state = None
        filter_matrix_reshape = filter_matrix.transpose(0, 1)
        for t in range(self.encoder_model.seq_len):
            _, encoder_hidden_state = self.encoder_model(inputs[t], adjacency_list, filter_matrix_reshape[t], encoder_hidden_state) # only use input at time t
            # encoder_hidden_state change from not-nan to nan, inputs[t] is always not nan
            # do not return output of the current time step, output = SLP(hidden state)
        return encoder_hidden_state

    def decoder(self, encoder_hidden_state, adjacency_list):
        """
        Decoder forward pass
        :param encoder_hidden_state: (num_layers, batch_size, self.hidden_state_size)
        :param labels: (self.horizon, batch_size, self.num_nodes * self.output_dim) [optional, not exist for inference]
        :param batches_seen: global step [optional, not exist for inference]
        :return: output: (self.horizon, batch_size, self.num_nodes * self.output_dim)
        """
        batch_size = encoder_hidden_state.size(1)
        go_symbol = torch.zeros((batch_size, self.num_nodes * self.decoder_model.output_dim), device=device)
        decoder_hidden_state = encoder_hidden_state # initialization of the first decoder_hidden_state of the decoding sequence
        decoder_input = go_symbol # input (x) to the decoding sequence

        outputs = []

        for t in range(self.decoder_model.horizon):
            decoder_output, decoder_hidden_state = self.decoder_model(decoder_input, adjacency_list, decoder_hidden_state)
            decoder_input = decoder_output # use output of the decoder unit as input of next decoder unit
            outputs.append(decoder_output)
        outputs = torch.stack(outputs)
        return outputs

    def forward(self, inputs, adjacency_list, filter_matrix): # inputs is not nan
        """
        seq2seq forward pass
        :param inputs: shape (seq_len, batch_size, num_sensor * input_dim)
        :param labels: shape (horizon, batch_size, num_sensor * output) optional
        :param batches_seen: batches seen till now
        :return: output: (self.horizon, batch_size, self.num_nodes * self.output_dim)
        """
        encoder_hidden_state = self.encoder(inputs, adjacency_list, filter_matrix) # encode first
        # self._logger.debug("Encoder complete, starting decoder")
        outputs = self.decoder(encoder_hidden_state, adjacency_list) # then decode
        # self._logger.debug("Decoder complete")

        return outputs
    
    
    
# Define DCRNNSupervisor
class DCRNNSupervisor:
    def __init__(self, **kwargs):
        self._kwargs = kwargs
        self._data_kwargs = kwargs.get('data')
        self._model_kwargs = kwargs.get('model')
        self._train_kwargs = kwargs.get('train')
        self.max_grad_norm = self._train_kwargs.get('max_grad_norm', 1.)
        self.batch_size = self._data_kwargs['batch_size']
        self.rolling_window = self._model_kwargs['rolling_window']

        # data set
        self.num_nodes = int(self._model_kwargs.get('num_nodes', 1))
        self.input_dim = int(self._model_kwargs.get('input_dim', 1))
        self.seq_len = int(self._model_kwargs.get('seq_len'))  # for the encoder, the length of training window
        self.output_dim = int(self._model_kwargs.get('output_dim', 1))
        self.use_curriculum_learning = bool(self._model_kwargs.get('use_curriculum_learning', False))
        self.horizon = int(self._model_kwargs.get('horizon', 1))  # for the decoder, the length of forecast window
        self.lag = int(self._model_kwargs.get('lag', 4))
        self.scarcity_prop = float(self._model_kwargs.get('scarcity_prop', 0.1))
        self._data = utils.load_dataset(self._data_kwargs.get('dataset_dir'), self._data_kwargs.get('batch_size'), self.seq_len, 
                                        self.horizon, self.lag, self.scarcity_prop, self._data_kwargs.get('train_test_split'), self._data_kwargs.get('train_val_split'))
        self.standard_scaler = self._data['scaler']
        self.adj_mx = self._data['adj_mx']

        # setup model
        dcrnn_model = DCRNNModel(self.adj_mx, **self._model_kwargs)
        self.dcrnn_model = dcrnn_model.cuda() if torch.cuda.is_available() else dcrnn_model
        print("Model created")
    
    def save_model(self, epoch):
        if not os.path.exists('models_mc/'):
            os.makedirs('models_mc/')

        config = dict(self._kwargs)
        config['model_state_dict'] = self.dcrnn_model.state_dict()
        config['epoch'] = epoch
        torch.save(config, 'models_mc/epo%d.tar' % epoch)
        print("Saved model at epoch {}".format(epoch+1))
        return 'models_mc/epo%d.tar' % epoch

    def load_model(self, epoch_num):
        self._setup_graph()
        assert os.path.exists('models_mc/epo%d.tar' % epoch_num), 'Weights at epoch %d not found' % epoch_num
        checkpoint = torch.load('models_mc/epo%d.tar' % epoch_num, map_location='cpu') # 存储都在cpu上
        self.dcrnn_model.load_state_dict(checkpoint['model_state_dict'])
        print("Loaded model at epoch {}".format(epoch_num+1))
        print("Started iterated h-step ahead forecast.")
        self.iterated_h_step_ahead_forecast()
        print("Finished iterated h-step ahead forecast.")

    def _setup_graph(self): # iterated one step ahead forecast
        with torch.no_grad():
            self.dcrnn_model = self.dcrnn_model.eval()
            
    def iterated_h_step_ahead_forecast(self): # iterated one step ahead forecast
        with torch.no_grad():
            data_test_array = self._data['data_test'].values
            y_true = data_test_array[self.seq_len:]
            len_y = len(y_true)       
            cutoff_y = int(int(len_y // self.horizon) * self.horizon)
            y_true = y_true[:cutoff_y]
            x = data_test_array[0:self.seq_len]
            Ey_total = utils.data_mask_generation(y_true)
            Ex_total = utils.data_mask_generation(data_test_array[:-self.horizon]) # [length, num_node]
            output_list = []
            for i in range(int(len(y_true)/self.horizon)):
                if i == 0:
                    # get masks & adj_mx
                    EA = utils.graph_mask_generation(x)
                    Ex = Ex_total[self.horizon * i: self.horizon * i + self.seq_len] # [length, num_node]
                    Ey = Ey_total[self.horizon * i: self.horizon * (i + 1)] # [length, num_node]
                    A = utils.compute_spillover_index(x, self.horizon, self.lag, self.scarcity_prop, standardized=True)
                    
                    # get x & y
                    y = y_true[self.horizon * i: self.horizon * (i + 1)]
                    x = self.standard_scaler.transform(x.reshape(-1, x.shape[-1])).reshape(x.shape)
                    
                    
                    # add the batch_size dimension
                    x = np.expand_dims(x, axis=0)
                    y = np.expand_dims(y, axis=0)
                    EA = np.expand_dims(EA, axis=0)
                    A = np.expand_dims(A, axis=0)
                    
                    # duplicate to fit the trained model
                    x = np.tile(x, (self.batch_size, 1, 1)) 
                    y = np.tile(y, (self.batch_size, 1, 1))
                    EA = np.tile(EA, (self.batch_size, 1, 1))
                    A = np.tile(A, (self.batch_size, 1, 1))
                    
                    x, y, EA, _, _, A = self._prepare_data(x, y, EA, Ex, Ey, A)
                    output = self.dcrnn_model(x, A, EA)
                    
                    # dim(output) = [horizon, batch_size, num_node]
                    output = self.standard_scaler.inverse_transform(output)
                    # use average pooling to get the final output
                    pooled_output = nn.functional.avg_pool2d(output, kernel_size=(output.size(1),1))
                    output = pooled_output.squeeze(dim=1)
                    # dim(output) = [horizon, num_node]               
                    
                    # batch_size wise and element wise multiplication
                    Ey_torch = torch.from_numpy(Ey).float()
                    output = output*(Ey_torch.to(output.device))
                    # dim(output) = [horizon, num_node]
                    output_list.append(output)                    
                else:
                    # reformulate x using the predicted x
                    x = x.transpose(0,1)[0] # # dim(x) = [seq_len, batch_size, num_node] --> dim(x) = [seq_len, num_nodes]
                    x = self.standard_scaler.inverse_transform(x)
                    x_cpu = x.cpu()
                    x = x_cpu.numpy()
                    input_x = output
                    input_x_cpu = input_x.cpu()
                    input_x_array = input_x_cpu.numpy()
                    x = x[self.horizon:, :]
                    x = np.vstack((x, input_x_array))
                    
                    # get masks & adj_mx
                    Ex = Ex_total[self.horizon * i: self.horizon * i + self.seq_len]
                    Ey = Ey_total[self.horizon * i: self.horizon * (i + 1)]
                    EA = utils.graph_mask_generation(x)
                    A = utils.compute_spillover_index(x, self.horizon, self.lag, self.scarcity_prop, standardized=True)
                    
                    # get x & y
                    x = self.standard_scaler.transform(x.reshape(-1, x.shape[-1])).reshape(x.shape)
                    y = y_true[self.horizon * i: self.horizon * (i + 1)]
                    
                    # add the batch_size dimension
                    x = np.expand_dims(x, axis=0)
                    y = np.expand_dims(y, axis=0)
                    EA = np.expand_dims(EA, axis=0)
                    A = np.expand_dims(A, axis=0)
                    
                    # duplicate to fit the trained model
                    x = np.tile(x, (self.batch_size, 1, 1)) 
                    y = np.tile(y, (self.batch_size, 1, 1))
                    EA = np.tile(EA, (self.batch_size, 1, 1))
                    A = np.tile(A, (self.batch_size, 1, 1))
                    x, y, EA, _, _, A = self._prepare_data(x, y, EA, Ex, Ey, A)
                    output = self.dcrnn_model(x, A, EA)
                    # dim(output) = [horizon, batch_size, num_node]
                    output = self.standard_scaler.inverse_transform(output)
                    
                    # use average pooling to get the final output
                    pooled_output = nn.functional.avg_pool2d(output, kernel_size=(output.size(1),1))
                    output = pooled_output.squeeze(dim=1)
                    # dim(output) = [horizon, num_node]             
                    
                    # batch_size wise and element wise multiplication
                    Ey_torch = torch.from_numpy(Ey).float()
                    output = output*(Ey_torch.to(output.device))
                    # dim(output) = [horizon, num_node]
                    output_list.append(output)
            
            concat_output = torch.cat(output_list, dim=0)
            concat_output_cpu = concat_output.cpu()
            concat_output_array = concat_output_cpu.numpy()
            
            column_names = self._data['data_test'].columns.tolist()
            sorted_result = {}
            for i in range(len(column_names)):
                column_name = column_names[i]
                sorted_result[column_name+'_forecast'] = concat_output_array[:,i]
                sorted_result[column_name+'_true'] = y_true[:,i]
            
            df = pd.DataFrame(sorted_result)
            
            if not os.path.exists('models_mc/'):
                os.makedirs('models_mc/')
            
            filename = 'iterated_h_step_ahead_forecast_result'+'_rolling_window_'+str(self.rolling_window)
            
            file_path = r'models_mc/{}.csv'.format(filename)
            df.to_csv(file_path, index=False)

    def train(self, **kwargs):
        kwargs.update(self._train_kwargs)
        return self._train(**kwargs)

    def evaluate(self, dataset='test'):
        """
        Computes mean L1Loss
        :return: mean L1Loss
        """
        with torch.no_grad():
            self.dcrnn_model = self.dcrnn_model.eval()

            val_iterator = self._data['{}_loader'.format(dataset)].get_iterator()
            losses = []

            y_truths = []
            y_preds = []

            for _, (x, y, EA, Ex, Ey, A) in enumerate(val_iterator):
                x, y, EA, Ex, Ey, A = self._prepare_data(x, y, EA, Ex, Ey, A)

                    
                output = self.dcrnn_model(x, A, EA)
                loss = self._compute_loss(y, output, Ey)
                losses.append(loss.item())

                y_truths.append(y.cpu())
                y_preds.append(output.cpu())

            mean_loss = np.mean(losses)

            #print('{} loss'.format(dataset), mean_loss)

            y_preds = np.concatenate(y_preds, axis=1)
            y_truths = np.concatenate(y_truths, axis=1)  # concatenate on batch dimension
            
            # transform back to torch.tensor
            y_preds = torch.tensor(y_preds, dtype=torch.float32, device='cuda')
            y_truths = torch.tensor(y_truths, dtype=torch.float32, device='cuda')
            
            # Initialize lists to hold scaled tensors
            y_truths_scaled = []
            y_preds_scaled = []
            
            # Loop over the first dimension to process each element
            for t in range(y_preds.shape[0]):
                y_truth = self.standard_scaler.inverse_transform(y_truths[t])
                y_pred =  self.standard_scaler.inverse_transform(y_preds[t])
                y_truths_scaled.append(y_truth)
                y_preds_scaled.append(y_pred)

            return mean_loss, {'prediction': y_preds_scaled, 'truth': y_truths_scaled}

    def _train(self, base_lr, steps, patience, epochs, lr_decay_ratio, test_every_n_epochs,epsilon, **kwargs):
        best_epoch_num = 0
        # steps is used in learning rate - will see if need to use it?
        min_val_loss = float('inf')
        wait = 0
        
        optimizer = torch.optim.Adam(self.dcrnn_model.parameters(), lr=base_lr, eps=epsilon)
        # base_lr: This is the basic learning rate.
        # epsilon: A term added to the denominator to improve numerical stability.
        
        lr_scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=steps, gamma=lr_decay_ratio)
        # milestones: A list of epoch indices. At each milestone, the learning rate is multiplied by gamma. 
        # gamma: The factor by which the learning rate will be reduced.
        
        
        print('Start training ...')

        # this will fail if model is loaded with a changed batch_size
        num_batches = self._data['train_val_loader'].num_batch

        for epoch_num in range(0, epochs):

            self.dcrnn_model = self.dcrnn_model.train()

            train_iterator = self._data['train_val_loader'].get_iterator()
            
            batches_seen = num_batches * epoch_num
            
            losses = []

            start_time = time.time()

            for _, (x, y, EA, Ex, Ey, A) in enumerate(train_iterator):
                optimizer.zero_grad()

                x, y, EA, Ex, Ey, A = self._prepare_data(x, y, EA, Ex, Ey, A)
                    # dim(x) = [seq_len, batch_size, num_node * input_dim]
                    # dim(y) = [horizon, batch_size, num_node * input_dim]
                    # dim(EA) = [batch_size, seq_len, num_node, num_node]
                    # dim(Ex) = [batch_size, seq_len, num_node]
                    # dim(Ey) = [batch_size, horizon, num_node]
                    # dim(A) = [batch_size, num_node, num_node]
                    # In fact, we do not need to apply Ex to x because 
                        # when we do standardization, the 0 value are transformed to a value which corresponds to inactive dates
                        # if we apply Ex, it will mess up the inactive dates with those originally close to mean
                
                output = self.dcrnn_model(x, A, EA)
                
                if batches_seen == 0:
                    p_count = sum(p.numel() for p in self.dcrnn_model.parameters() if p.requires_grad)
                    print(f'Number of parameters in dcrnn_model: {p_count}')
                    # this is a workaround to accommodate dynamically registered parameters in DCGRUCell
                    optimizer = torch.optim.Adam(self.dcrnn_model.parameters(), lr=base_lr, eps=epsilon)


                loss = self._compute_loss(y, output, Ey)

                losses.append(loss.item())
                batches_seen += 1
                loss.backward()
                
                
                ## show gradient
                # for name, param in self.dcrnn_model.named_parameters():
                #     if param.grad is not None:
                #         print(f'Epoch {epoch_num+1}, Parameter {name}, Gradient {param.grad}')
                #     else:
                #         print(f'Epoch {epoch_num+1}, Parameter {name}, None gradient')
                
                # gradient clipping - this does it in place
                torch.nn.utils.clip_grad_norm_(self.dcrnn_model.parameters(), self.max_grad_norm)
                
                optimizer.step()
                
                
                
            print("epoch complete ...")
            lr_scheduler.step() # only update scheduler after epochs
            print("evaluating now ...")

            val_loss, _ = self.evaluate(dataset='test')

            end_time = time.time()

            print('Epoch [{}/{}] train_mae: {:.10f}, val_mae: {:.10f}, lr: {:.6f}, ' \
                          '{:.1f}s'.format(epoch_num+1, epochs,
                                           np.mean(losses), val_loss, lr_scheduler.get_lr()[0],
                                           (end_time - start_time)))

            # valid loss 更小就保存，否则计算patience
            if val_loss < min_val_loss:
                min_val_loss = val_loss
                wait = 0
                self.save_model(epoch_num)
                best_epoch_num = epoch_num
                print('Best validation loss: %.10f' % val_loss)

            elif val_loss >= min_val_loss:
                wait += 1
                if wait == patience:
                    early_stop_epoch_num = epoch_num + 1
                    print('Early stopping at epoch: %d' % early_stop_epoch_num)
                    print('Early stopping with: %.10f' % min_val_loss)
                    break
        
        self.load_model(best_epoch_num)

    def _prepare_data(self, x, y, EA, Ex, Ey, A): # free from error
        x, y, EA, Ex, Ey, A = self._get_x_y(x, y, EA, Ex, Ey, A)
        x, y = self._get_x_y_in_correct_dims(x, y)
        return x.to(device), y.to(device), EA.to(device), Ex.to(device), Ey.to(device), A.to(device)

    def _get_x_y(self, x, y, EA, Ex, Ey, A): # free from error
        """
        :param x: shape (batch_size, seq_len, num_sensor, input_dim)
        :param y: shape (batch_size, horizon, num_sensor, input_dim)
        :returns x shape (seq_len, batch_size, num_sensor, input_dim)
                 y shape (horizon, batch_size, num_sensor, input_dim)
        """
        x = torch.from_numpy(x).float()
        y = torch.from_numpy(y).float()
        EA = torch.from_numpy(EA).float()
        Ex = torch.from_numpy(Ex).float()
        Ey = torch.from_numpy(Ey).float()
        A = torch.from_numpy(A).float()
        # self._logger.debug("X: {}".format(x.size()))
        # self._logger.debug("y: {}".format(y.size()))
        if x.dim() == 3:
             x = x.unsqueeze(-1)  # Adds input_dim as the last dimension
        if y.dim() == 3:
             y = y.unsqueeze(-1)  # Adds input_dim as the last dimension
        x = x.permute(1, 0, 2, 3)
        y = y.permute(1, 0, 2, 3)
        return x, y, EA, Ex, Ey, A

    def _get_x_y_in_correct_dims(self, x, y): # no need to handle the dimension of E and A
        """
        :param x: shape (seq_len, batch_size, num_sensor, input_dim)
        :param y: shape (horizon, batch_size, num_sensor, input_dim)
        :return: x: shape (seq_len, batch_size, num_sensor * input_dim)
                 y: shape (horizon, batch_size, num_sensor * output_dim)
        """
        batch_size = x.size(1)
        x = x.view(self.seq_len, batch_size, self.num_nodes * self.input_dim)
        y = y[..., :self.output_dim].view(self.horizon, batch_size,
                                          self.num_nodes * self.output_dim)
        return x, y
    
    def _compute_loss(self, y_true, y_predicted, Ey):
        # dim(Ey) = [batch_size, horizon, num_node]
        # dim(y_true) = [horizon, batch_size, num_node]
        # dim(y_predicted) = [horizon, batch_size, num_node]
        y_true = self.standard_scaler.inverse_transform(y_true)
        y_predicted = self.standard_scaler.inverse_transform(y_predicted)
        return mae_loss(y_predicted, y_true, Ey)


   
    
    
### Training
def main(args):
    with open(args.config_filename) as f:
        supervisor_config = yaml.load(f, Loader=yaml.SafeLoader)
        supervisor = DCRNNSupervisor(**supervisor_config) # initialize supervisor

        supervisor.train()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config_filename', default='data/model/dcrnn_test_config_v4.yaml', type=str,
                        help='Configuration filename for restoring the model.')
    parser.add_argument('--use_cpu_only', default=False, type=bool, help='Set to true to only use cpu.')
    args = parser.parse_args()
    main(args)
    
    
    
