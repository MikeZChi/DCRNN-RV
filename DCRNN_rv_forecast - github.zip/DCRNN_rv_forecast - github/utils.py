import logging
import numpy as np
import os
import pickle
import scipy.sparse as sp
import sys
import tensorflow as tf
import pandas as pd
from scipy.sparse import linalg
# from sklearn.preprocessing import StandardScaler
from torch.utils.data import TensorDataset, DataLoader
import torch
from statsmodels.tsa.api import VAR
from scipy import stats



class DataLoader(object):
    def __init__(self, xs, ys, batch_size, shuffle=False):
        """
        Initializes the DataLoader object.
        
        :param xs: Numpy array of all input features.
        :param ys: Numpy array of all target values.
        :param batch_size: The number of samples per batch.
        :param shuffle: Whether to shuffle the data before creating batches.
        """
        self.batch_size = batch_size
        self.current_ind = 0
        self.size = len(xs) - (len(xs) % batch_size)  # Adjust size to discard incomplete batch
        
        if shuffle:
            permutation = np.random.permutation(self.size)
            xs, ys = xs[permutation], ys[permutation]
        
        self.xs = xs[:self.size]
        self.ys = ys[:self.size]
        self.num_batch = int(self.size // self.batch_size)

    def get_iterator(self):
        """
        Returns an iterator to go over the batches.
        """
        self.current_ind = 0

        def _wrapper():
            while self.current_ind < self.num_batch:
                start_ind = self.batch_size * self.current_ind
                end_ind = start_ind + self.batch_size
                x_i = self.xs[start_ind:end_ind, ...]
                y_i = self.ys[start_ind:end_ind, ...]
                yield (x_i, y_i)
                self.current_ind += 1

        return _wrapper()

class StandardScaler:
    """
    Standardizes the input by removing the mean and scaling to unit variance.
    Uses NumPy for fitting and transforming, and PyTorch for inverse transforming.
    """
    def __init__(self, mean=None, std=None):
        # Initialize with NumPy arrays or None
        self.mean = np.array(mean, dtype=np.float32) if mean is not None else None
        self.std = np.array(std, dtype=np.float32) if std is not None else None

    def transform(self, data):
        """
        Transform the data using the mean and std obtained from fitting.
        Assumes data is a NumPy array.
        """
        return (data - self.mean) / self.std

    def inverse_transform(self, data):
        """
        Inverse the transformation applied to PyTorch tensors.
        Assumes data is a PyTorch tensor.
        """
        # Ensure mean and std are tensors and on the same device as data
        mean = torch.as_tensor(self.mean, dtype=data.dtype, device=data.device)
        std = torch.as_tensor(self.std, dtype=data.dtype, device=data.device)
        return (data * std) + mean




def add_simple_summary(writer, names, values, global_step):
    """
    Writes summary for a list of scalars.
    :param writer:
    :param names:
    :param values:
    :param global_step:
    :return:
    """
    for name, value in zip(names, values):
        summary = tf.Summary()
        summary_value = summary.value.add()
        summary_value.simple_value = value
        summary_value.tag = name
        writer.add_summary(summary, global_step)


def calculate_normalized_laplacian(adj):
    """
    # L = D^-1/2 (D-A) D^-1/2 = I - D^-1/2 A D^-1/2
    # D = diag(A 1)
    :param adj:
    :return:
    """
    adj = sp.coo_matrix(adj)
    d = np.array(adj.sum(1))
    d_inv_sqrt = np.power(d, -0.5).flatten()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
    d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
    normalized_laplacian = sp.eye(adj.shape[0]) - adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt).tocoo()
    return normalized_laplacian


def calculate_random_walk_matrix(adj_mx):
    adj_mx = sp.coo_matrix(adj_mx)
    d = np.array(adj_mx.sum(1))
    d_inv = np.power(d, -1).flatten()
    d_inv[np.isinf(d_inv)] = 0.
    d_mat_inv = sp.diags(d_inv)
    random_walk_mx = d_mat_inv.dot(adj_mx).tocoo()
    return random_walk_mx


def calculate_reverse_random_walk_matrix(adj_mx):
    return calculate_random_walk_matrix(np.transpose(adj_mx))


def calculate_scaled_laplacian(adj_mx, lambda_max=2, undirected=True):
    if undirected:
        adj_mx = np.maximum.reduce([adj_mx, adj_mx.T])
    L = calculate_normalized_laplacian(adj_mx)
    if lambda_max is None:
        lambda_max, _ = linalg.eigsh(L, 1, which='LM')
        lambda_max = lambda_max[0]
    L = sp.csr_matrix(L)
    M, _ = L.shape
    I = sp.identity(M, format='csr', dtype=L.dtype)
    L = (2 / lambda_max * L) - I
    return L.astype(np.float32)


def config_logging(log_dir, log_filename='info.log', level=logging.INFO):
    # Add file handler and stdout handler
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    # Create the log directory if necessary.
    try:
        os.makedirs(log_dir)
    except OSError:
        pass
    file_handler = logging.FileHandler(os.path.join(log_dir, log_filename))
    file_handler.setFormatter(formatter)
    file_handler.setLevel(level=level)
    # Add console handler.
    console_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(console_formatter)
    console_handler.setLevel(level=level)
    logging.basicConfig(handlers=[file_handler, console_handler], level=level)


def get_logger(log_dir, name, log_filename='info.log', level=logging.INFO):
    logger = logging.getLogger(name)
    logger.setLevel(level)
    # Add file handler and stdout handler
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler = logging.FileHandler(os.path.join(log_dir, log_filename))
    file_handler.setFormatter(formatter)
    # Add console handler.
    console_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(console_formatter)
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    # Add google cloud log handler
    logger.info('Log directory: %s', log_dir)
    return logger


def get_total_trainable_parameter_size():
    """
    Calculates the total number of trainable parameters in the current graph.
    :return:
    """
    total_parameters = 0
    for variable in tf.trainable_variables():
        # shape is an array of tf.Dimension
        total_parameters += np.product([x.value for x in variable.get_shape()])
    return total_parameters

def compute_spillover_index(data, horizon, lag, scarcity_prop, standardized=True):
    # Input data should be np.array
    data_cleaned = data[~np.any(data == 0, axis=1)]
    # Fit VAR model
    model = VAR(data_cleaned)
    results = model.fit(maxlags=lag)
    
    # Manually Compute Forecast Error Variance Decomposition (FEVD)
    Sigma = results.sigma_u  # Covariance matrix of residuals
    A = results.orth_ma_rep(maxn=horizon - 1)  # MA representation up to n_ahead-1 steps
    
    Sigma_A = []
    A_Sigma_A = []
    
    for h in range(horizon):
        # Numerator
        Sigma_A_h = (A[h] @ Sigma @ np.linalg.inv(np.diag(np.sqrt(np.diag(Sigma))))) ** 2
        Sigma_A.append(Sigma_A_h)
        
        # Denominator
        A_Sigma_A_h = A[h] @ Sigma @ A[h].T
        A_Sigma_A.append(A_Sigma_A_h)
    
    # Numerator: cumulative sum of Sigma_A
    num = np.cumsum(Sigma_A, axis=0)
    
    # Denominator: cumulative sum of A_Sigma_A
    den = np.cumsum(A_Sigma_A, axis=0)
    
    # Generalized FEVD
    gfevd = np.array([num[h] / np.diag(den[h])[:, None] for h in range(horizon)])
    
    if standardized:
        # Standardize each FEVD matrix so that each row sums to 1
        gfevd = np.array([fevd / fevd.sum(axis=1, keepdims=True) for fevd in gfevd])
    
    # Aggregate results over n_ahead steps
    spillover_matrix = gfevd[-1]
    
    # VSP from row to column so can be used as adjacency matrix
    spillover_matrix = spillover_matrix.T ## row --> column: if node i --> node j, A_{ij} != 0
    
    # Convert to percentage
    spillover_matrix *= 100      
    
    # Calculate 'to' and 'from' others
    K = spillover_matrix.shape[0]
    
    # Create results DataFrame
    results_df = pd.DataFrame(spillover_matrix, columns=results.names, index=results.names)
    
    # Increase sparcity
    vsp_df_sparse = results_df.copy()
    threshold = pd.Series(results_df.values.flatten()).quantile(scarcity_prop)
    vsp_df_sparse[vsp_df_sparse < threshold] = 0
    vsp_np_sparse = vsp_df_sparse.values
    np.fill_diagonal(vsp_np_sparse, 0)

    if standardized:
        vsp_np_sparse = vsp_np_sparse / K
        return vsp_np_sparse
    else:
        return vsp_np_sparse # for each train_x batch, dim(results_array) = [num_node, num_node]


def load_dataset(dataset_dir, batch_size, seq_len, horizon, lag, scarcity_prop, train_test_split, train_valid_split):
    """
    Parameters
    ----------
    dataset_dir : file_path to the dataset
    seq_len : int. look_back window
    horizon : int. predict window
    train_test_split : (train+valid)/total
    train_valid_split : train/(train+valid)

    """
    # Load data from CSV
    data = pd.read_csv(dataset_dir, index_col=0)
    
    # Calculate split index
    total_rows = data.shape[0]
    train_valid_end_idx = int(total_rows * train_test_split)  # Training set ends at this index
    train_end_idx = int(train_valid_end_idx * train_valid_split)
    data_train = data[0:train_end_idx]
    data_valid = data[train_end_idx:train_valid_end_idx]
    data_train_val = pd.concat([data_train, data_valid])
    data_test = data[train_valid_end_idx:]
    data_train_cleaned = data_train_val[~np.any(data_train_val == 0, axis=1)]
    fixed_A = compute_spillover_index(data_train_cleaned.values, horizon, lag, scarcity_prop, standardized=True)

    # Helper function to create datasets based on sequence length and horizon
    def create_dataset(data, start_index, end_index, seq_len, horizon):
        X, Y = [], []
        for i in range(start_index, end_index - seq_len - horizon + 1):
            X.append(data.iloc[i:i+seq_len].values)
            Y.append(data.iloc[i+seq_len:i+seq_len+horizon].values)
        return np.array(X), np.array(Y)

    # Split data into training and validation datasets
    train_x, train_y = create_dataset(data, 0, train_end_idx, seq_len, horizon)
    val_x, val_y = create_dataset(data, train_end_idx, train_valid_end_idx, seq_len, horizon)
    train_val_x, train_val_y = create_dataset(data, 0, train_valid_end_idx, seq_len, horizon)
    test_x, test_y = create_dataset(data, train_valid_end_idx, total_rows, seq_len, horizon)
    # Flatten the training data to fit the scaler
    flat_train_x = train_x.reshape(-1, train_x.shape[-1])
    mean = flat_train_x.mean(axis=0)
    std = flat_train_x.std(axis=0)
    # Create an instance of the custom StandardScaler
    scaler = StandardScaler(mean, std)
    train_x = scaler.transform(train_x.reshape(-1, train_x.shape[-1])).reshape(train_x.shape)
    train_y = scaler.transform(train_y.reshape(-1, train_y.shape[-1])).reshape(train_y.shape)
    val_x = scaler.transform(val_x.reshape(-1, val_x.shape[-1])).reshape(val_x.shape)
    val_y = scaler.transform(val_y.reshape(-1, val_y.shape[-1])).reshape(val_y.shape)
    train_val_x = scaler.transform(train_val_x.reshape(-1, train_val_x.shape[-1])).reshape(train_val_x.shape)
    train_val_y = scaler.transform(train_val_y.reshape(-1, train_val_y.shape[-1])).reshape(train_val_y.shape)
    test_x = scaler.transform(test_x.reshape(-1, test_x.shape[-1])).reshape(test_x.shape)
    test_y = scaler.transform(test_y.reshape(-1, test_y.shape[-1])).reshape(test_y.shape)

    # Create custom DataLoaders
    train_loader = DataLoader(train_x, train_y, batch_size, shuffle=True)
    val_loader = DataLoader(val_x, val_y, batch_size, shuffle=False)
    train_val_loader = DataLoader(train_val_x, train_val_y, batch_size, shuffle=True)
    test_loader = DataLoader(test_x, test_y, batch_size, shuffle=False)

    # Return everything packaged in a dictionary
    return {
        'train_loader': train_loader,
        'val_loader': val_loader,
        'test_loader': test_loader,
        'train_val_loader': train_val_loader,
        'scaler': scaler,
        'data_train': data_train,
        'data_valid':data_valid,
        'data_test': data_test,
        'adj_mx': fixed_A
    }

# Function to compute the mode along the batch_size dimension
def compute_mode(tensor):
    tensor_cpu = tensor.cpu()
    tensor = tensor_cpu.numpy()  # Convert to numpy array for mode calculation
    mode_result = stats.mode(tensor, axis=0)[0]  # Compute mode along batch_size dimension
    return torch.tensor(mode_result)

'''
def load_graph_data(pkl_filename):
    sensor_ids, sensor_id_to_ind, adj_mx = load_pickle(pkl_filename)
    return sensor_ids, sensor_id_to_ind, adj_mx


def load_pickle(pickle_file):
    try:
        with open(pickle_file, 'rb') as f:
            pickle_data = pickle.load(f)
    except UnicodeDecodeError as e:
        with open(pickle_file, 'rb') as f:
            pickle_data = pickle.load(f, encoding='latin1')
    except Exception as e:
        print('Unable to load data ', pickle_file, ':', e)
        raise
    return pickle_data
'''
